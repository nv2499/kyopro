
export interface Product {
  id: string;
  model: string;
  type: 'Color' | 'B&W';
  speed: number; // ppm
  category: 'A4' | 'A3';
  priceRange: string;
  description: string;
  features: string[];
  imageUrl: string;
  images?: string[];
}

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
  timestamp: Date;
}

export enum PageRoutes {
  HOME = '/',
  CATALOG = '/catalog',
  PRODUCT = '/product/:id',
  CONTACT = '/contact',
  COMPARE = '/compare'
}
