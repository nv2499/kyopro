
import React, { useState } from 'react';
import { Mail, Phone, MapPin, Send, Wrench, MessageSquare } from 'lucide-react';
import SeoHead from '../components/SeoHead';

const Contact: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'sales' | 'service'>('sales');
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    message: '',
    modelNumber: '',
    issueDescription: ''
  });
  const [status, setStatus] = useState<'idle' | 'success'>('idle');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Simulate form submission
    setStatus('success');
    setTimeout(() => setStatus('idle'), 3000);
    setFormData({ 
      name: '', 
      email: '', 
      phone: '', 
      message: '',
      modelNumber: '',
      issueDescription: ''
    });
  };

  return (
    <>
      <SeoHead 
        title="ติดต่อเรา" 
        description="ติดต่อทีมงาน Kyocera Thailand เพื่อขอใบเสนอราคา หรือแจ้งซ่อม โทร 02-123-4567" 
      />

      <div className="bg-gray-50 min-h-screen py-12">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <h1 className="text-3xl font-bold text-gray-900 mb-4">ติดต่อเรา</h1>
            <p className="text-gray-600">
              สนใจสินค้า หรือต้องการปรึกษาโซลูชั่นงานเอกสาร ติดต่อเราได้ทันที
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 max-w-5xl mx-auto">
            {/* Contact Info */}
            <div className="space-y-8">
              <div className="bg-white p-8 rounded-2xl shadow-sm border border-gray-100">
                <h3 className="text-xl font-bold text-gray-800 mb-6">ข้อมูลการติดต่อ</h3>
                
                <div className="space-y-6">
                  <div className="flex items-start gap-4">
                    <div className="bg-red-50 p-3 rounded-lg text-kyocera-red">
                      <Phone size={24} />
                    </div>
                    <div>
                      <h4 className="font-bold text-gray-900">โทรศัพท์</h4>
                      <p className="text-gray-600">02-123-4567 (ฝ่ายขาย)</p>
                      <p className="text-gray-600">02-123-4568 (แจ้งซ่อม)</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-4">
                    <div className="bg-red-50 p-3 rounded-lg text-kyocera-red">
                      <Mail size={24} />
                    </div>
                    <div>
                      <h4 className="font-bold text-gray-900">อีเมล</h4>
                      <p className="text-gray-600">sales@kyopro-thailand.com</p>
                      <p className="text-gray-600">support@kyopro-thailand.com</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-4">
                    <div className="bg-red-50 p-3 rounded-lg text-kyocera-red">
                      <MapPin size={24} />
                    </div>
                    <div>
                      <h4 className="font-bold text-gray-900">ที่อยู่สำนักงาน</h4>
                      <p className="text-gray-600 leading-relaxed">
                        123 อาคารสาทรทาวเวอร์ ชั้น 15 ถนนสาทรใต้<br/>
                        แขวงยานนาวา เขตสาทร<br/>
                        กรุงเทพมหานคร 10120
                      </p>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="bg-gray-200 h-64 rounded-2xl overflow-hidden relative">
                 <div className="absolute inset-0 flex items-center justify-center text-gray-500">
                    <span className="font-medium">Map Placeholder (Google Maps Embed)</span>
                 </div>
              </div>
            </div>

            {/* Contact Form with Tabs */}
            <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden flex flex-col">
              {/* Tabs */}
              <div className="flex border-b border-gray-100">
                <button 
                  onClick={() => setActiveTab('sales')}
                  className={`flex-1 py-4 text-sm font-bold flex items-center justify-center gap-2 transition-colors relative ${
                    activeTab === 'sales' 
                      ? 'text-kyocera-red bg-white' 
                      : 'text-gray-500 bg-gray-50 hover:bg-gray-100'
                  }`}
                >
                  <MessageSquare size={18} /> ติดต่อฝ่ายขาย
                  {activeTab === 'sales' && <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-kyocera-red" />}
                </button>
                <button 
                  onClick={() => setActiveTab('service')}
                  className={`flex-1 py-4 text-sm font-bold flex items-center justify-center gap-2 transition-colors relative ${
                    activeTab === 'service' 
                      ? 'text-kyocera-red bg-white' 
                      : 'text-gray-500 bg-gray-50 hover:bg-gray-100'
                  }`}
                >
                  <Wrench size={18} /> แจ้งซ่อม / ปัญหา
                  {activeTab === 'service' && <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-kyocera-red" />}
                </button>
              </div>

              <div className="p-8">
                <h3 className="text-xl font-bold text-gray-800 mb-6">
                  {activeTab === 'sales' ? 'ส่งข้อความถึงเรา' : 'แบบฟอร์มแจ้งซ่อม'}
                </h3>
                
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">ชื่อ-นามสกุล / บริษัท</label>
                    <input 
                      required
                      type="text" 
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-kyocera-red focus:border-transparent outline-none transition"
                      placeholder="ระบุชื่อผู้ติดต่อ"
                      value={formData.name}
                      onChange={e => setFormData({...formData, name: e.target.value})}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">อีเมล</label>
                    <input 
                      required
                      type="email" 
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-kyocera-red focus:border-transparent outline-none transition"
                      placeholder="example@company.com"
                      value={formData.email}
                      onChange={e => setFormData({...formData, email: e.target.value})}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">เบอร์โทรศัพท์</label>
                    <input 
                      required
                      type="tel" 
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-kyocera-red focus:border-transparent outline-none transition"
                      placeholder="08x-xxx-xxxx"
                      value={formData.phone}
                      onChange={e => setFormData({...formData, phone: e.target.value})}
                    />
                  </div>

                  {activeTab === 'sales' ? (
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">ข้อความ / รุ่นที่สนใจ</label>
                      <textarea 
                        required
                        rows={4}
                        className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-kyocera-red focus:border-transparent outline-none transition"
                        placeholder="สอบถามราคาเช่าซื้อ รุ่น..."
                        value={formData.message}
                        onChange={e => setFormData({...formData, message: e.target.value})}
                      ></textarea>
                    </div>
                  ) : (
                    <>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">รุ่นเครื่อง / Serial Number</label>
                        <input 
                          required
                          type="text" 
                          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-kyocera-red focus:border-transparent outline-none transition"
                          placeholder="เช่น TASKalfa 2554ci / AB123456"
                          value={formData.modelNumber}
                          onChange={e => setFormData({...formData, modelNumber: e.target.value})}
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">รายละเอียดปัญหาที่พบ</label>
                        <textarea 
                          required
                          rows={4}
                          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-kyocera-red focus:border-transparent outline-none transition"
                          placeholder="เช่น กระดาษติด, พิมพ์เป็นเส้นดำ..."
                          value={formData.issueDescription}
                          onChange={e => setFormData({...formData, issueDescription: e.target.value})}
                        ></textarea>
                      </div>
                    </>
                  )}
                  
                  <button 
                    type="submit" 
                    className="w-full bg-kyocera-red hover:bg-red-700 text-white font-bold py-3 rounded-lg transition flex items-center justify-center gap-2"
                  >
                    <Send size={18} />
                    {activeTab === 'sales' ? 'ส่งข้อความ' : 'ส่งแจ้งซ่อม'}
                  </button>

                  {status === 'success' && (
                    <div className="p-3 bg-green-50 text-green-700 rounded-lg text-center text-sm font-medium animate-in fade-in slide-in-from-top-2">
                      ส่งข้อมูลเรียบร้อยแล้ว เจ้าหน้าที่จะติดต่อกลับโดยเร็วที่สุด
                    </div>
                  )}
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Contact;
