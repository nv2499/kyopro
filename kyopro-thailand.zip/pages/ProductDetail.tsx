
import React, { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { products } from '../data/products';
import { Check, ArrowLeft, Phone, Printer, Layers, ChevronLeft, ChevronRight } from 'lucide-react';
import SeoHead from '../components/SeoHead';
import { useComparison } from '../context/ComparisonContext';

const ProductDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const product = products.find(p => p.id === id);
  const { isInComparison, toggleProduct } = useComparison();
  const [activeImageIndex, setActiveImageIndex] = useState(0);

  if (!product) {
    return (
      <div className="min-h-screen flex items-center justify-center flex-col">
        <h2 className="text-2xl font-bold text-gray-800 mb-4">ไม่พบสินค้านี้</h2>
        <Link to="/catalog" className="text-kyocera-red hover:underline">กลับไปหน้าสินค้า</Link>
      </div>
    );
  }

  const isSelected = isInComparison(product.id);
  const images = product.images && product.images.length > 0 ? product.images : [product.imageUrl];

  const handleNextImage = () => {
    setActiveImageIndex((prev) => (prev + 1) % images.length);
  };

  const handlePrevImage = () => {
    setActiveImageIndex((prev) => (prev - 1 + images.length) % images.length);
  };

  return (
    <>
      <SeoHead 
        title={product.model} 
        description={`รายละเอียด ${product.model} ${product.description}`}
        image={images[0]}
      />

      <div className="bg-white min-h-screen py-12">
        <div className="container mx-auto px-4">
          <Link to="/catalog" className="inline-flex items-center text-gray-500 hover:text-kyocera-red mb-8 transition">
            <ArrowLeft size={16} className="mr-1" /> กลับไปหน้าสินค้า
          </Link>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Gallery Section */}
            <div className="flex flex-col gap-4">
              <div className="bg-gray-50 rounded-2xl p-4 sm:p-8 flex items-center justify-center border border-gray-100 relative group min-h-[400px]">
                {/* Navigation Arrows */}
                {images.length > 1 && (
                  <>
                    <button 
                      onClick={handlePrevImage}
                      className="absolute left-4 top-1/2 -translate-y-1/2 bg-white/80 hover:bg-white p-2 rounded-full shadow-md text-gray-800 transition opacity-0 group-hover:opacity-100 z-10"
                      aria-label="Previous image"
                    >
                      <ChevronLeft size={24} />
                    </button>
                    <button 
                      onClick={handleNextImage}
                      className="absolute right-4 top-1/2 -translate-y-1/2 bg-white/80 hover:bg-white p-2 rounded-full shadow-md text-gray-800 transition opacity-0 group-hover:opacity-100 z-10"
                      aria-label="Next image"
                    >
                      <ChevronRight size={24} />
                    </button>
                  </>
                )}
                
                <img 
                  src={images[activeImageIndex]} 
                  alt={`${product.model} view ${activeImageIndex + 1}`} 
                  className="max-w-full h-auto max-h-[400px] object-contain drop-shadow-xl transition-all duration-300"
                />
              </div>

              {/* Thumbnails */}
              {images.length > 1 && (
                <div className="flex gap-3 overflow-x-auto pb-2 scrollbar-hide">
                  {images.map((img, index) => (
                    <button
                      key={index}
                      onClick={() => setActiveImageIndex(index)}
                      className={`relative flex-shrink-0 w-20 h-20 rounded-lg overflow-hidden border-2 transition-all ${
                        activeImageIndex === index 
                          ? 'border-kyocera-red ring-2 ring-red-100' 
                          : 'border-transparent hover:border-gray-300'
                      }`}
                    >
                      <img 
                        src={img} 
                        alt={`Thumbnail ${index + 1}`} 
                        className="w-full h-full object-cover"
                      />
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Info Section */}
            <div>
              <div className="flex items-center gap-3 mb-4">
                <span className="px-3 py-1 bg-red-50 text-kyocera-red text-xs font-bold rounded-full uppercase tracking-wider">
                  Kyocera Genuine
                </span>
                <span className="px-3 py-1 bg-gray-100 text-gray-600 text-xs font-bold rounded-full uppercase tracking-wider">
                  {product.category} Size
                </span>
              </div>
              
              <h1 className="text-4xl font-bold text-gray-900 mb-4">{product.model}</h1>
              <p className="text-xl text-gray-500 mb-8">{product.description}</p>

              <div className="bg-gray-50 rounded-xl p-6 mb-8 border border-gray-100">
                <h3 className="text-lg font-bold text-gray-800 mb-4 flex items-center gap-2">
                  <Printer size={20} className="text-kyocera-red" />
                  คุณสมบัติเด่น
                </h3>
                <ul className="space-y-3">
                  {product.features.map((feature, idx) => (
                    <li key={idx} className="flex items-start gap-3">
                      <div className="mt-1 bg-green-100 p-0.5 rounded-full">
                        <Check size={14} className="text-green-600" />
                      </div>
                      <span className="text-gray-700">{feature}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="flex flex-col gap-4">
                <div className="flex flex-col sm:flex-row gap-4">
                    <Link 
                    to="/contact" 
                    className="flex-1 bg-kyocera-red text-white py-4 px-6 rounded-lg font-bold text-center hover:bg-red-700 transition flex items-center justify-center gap-2"
                    >
                    <Phone size={20} />
                    ติดต่อขอราคา / เช่า
                    </Link>
                    <button 
                    onClick={() => toggleProduct(product.id)}
                    className={`flex-1 border-2 py-4 px-6 rounded-lg font-bold text-center transition flex items-center justify-center gap-2 ${
                        isSelected 
                        ? 'border-kyocera-black bg-kyocera-black text-white' 
                        : 'border-gray-200 text-gray-700 hover:bg-gray-50'
                    }`}
                    >
                    <Layers size={20} />
                    {isSelected ? 'เลือกแล้ว (คลิกเพื่อออก)' : 'เปรียบเทียบรุ่นนี้'}
                    </button>
                </div>
                <button 
                  onClick={() => window.alert('โปรดใช้ Chatbot มุมขวาล่างเพื่อสอบถามข้อมูลเพิ่มเติม')}
                  className="w-full text-sm text-gray-500 py-2 hover:underline"
                >
                  สอบถามข้อมูลเพิ่มเติมกับ AI
                </button>
              </div>
              
              <p className="mt-4 text-xs text-gray-400 text-center sm:text-left">
                *เงื่อนไขการรับประกันและการเช่าเป็นไปตามที่บริษัทกำหนด
              </p>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default ProductDetail;
