
import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useComparison } from '../context/ComparisonContext';
import { products } from '../data/products';
import { X, ArrowLeft, CheckCircle, AlertCircle, Bot, Send, Sparkles } from 'lucide-react';
import SeoHead from '../components/SeoHead';
import { sendMessageToGemini } from '../services/geminiService';

const Compare: React.FC = () => {
  const { selectedIds, toggleProduct, clearComparison } = useComparison();
  const [aiQuery, setAiQuery] = useState('');
  const [aiResponse, setAiResponse] = useState('');
  const [isAiLoading, setIsAiLoading] = useState(false);
  
  const selectedProducts = products.filter(p => selectedIds.includes(p.id));

  const handleAiCompare = async (queryOverride?: string) => {
    const query = queryOverride || aiQuery;
    if (!query.trim()) return;

    setIsAiLoading(true);
    setAiResponse('');

    const productContext = selectedProducts.map(p =>
      `- Model: ${p.model}
       Type: ${p.type}
       Speed: ${p.speed} ppm
       Category: ${p.category}
       Price Range: ${p.priceRange}
       Description: ${p.description}
       Features: ${p.features.join(', ')}`
    ).join('\n\n');

    const prompt = `
    Context: The user is comparing the following Kyocera models on a comparison page:
    ${productContext}

    User Question: ${query}

    Instruction: Analyze the differences and answer the user's question specifically comparing these models. Keep it concise, helpful, and highlight the key strengths of each relative to the other.
    `;

    try {
      // Pass empty history to start a fresh comparison context
      const response = await sendMessageToGemini([], prompt);
      setAiResponse(response);
      if (!queryOverride) setAiQuery('');
    } catch (error) {
      console.error(error);
      setAiResponse("ขออภัย ระบบขัดข้อง ไม่สามารถเปรียบเทียบข้อมูลได้ในขณะนี้");
    } finally {
      setIsAiLoading(false);
    }
  };

  if (selectedProducts.length === 0) {
    return (
      <div className="min-h-screen bg-gray-50 flex flex-col items-center justify-center p-4">
        <div className="bg-white p-8 rounded-2xl shadow-sm border border-gray-100 text-center max-w-md">
          <AlertCircle size={48} className="mx-auto text-gray-300 mb-4" />
          <h2 className="text-2xl font-bold text-gray-900 mb-2">ยังไม่มีสินค้าที่เลือก</h2>
          <p className="text-gray-500 mb-6">กรุณาเลือกสินค้าจากหน้ารายการสินค้าเพื่อนำมาเปรียบเทียบ</p>
          <Link to="/catalog" className="bg-kyocera-red text-white px-6 py-3 rounded-lg font-bold hover:bg-red-700 transition inline-block">
            ไปที่รายการสินค้า
          </Link>
        </div>
      </div>
    );
  }

  return (
    <>
      <SeoHead title="เปรียบเทียบสินค้า" description="เปรียบเทียบสเปคเครื่องถ่ายเอกสาร Kyocera รุ่นต่างๆ" />
      
      <div className="bg-gray-50 min-h-screen py-12">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center mb-8">
            <h1 className="text-3xl font-bold text-gray-900">เปรียบเทียบสินค้า</h1>
            <div className="flex gap-4">
                <Link to="/catalog" className="text-gray-500 hover:text-kyocera-red flex items-center gap-2">
                    <ArrowLeft size={16} /> เลือกเพิ่ม
                </Link>
                <button onClick={clearComparison} className="text-red-600 hover:text-red-800 text-sm font-medium">
                    ล้างค่าทั้งหมด
                </button>
            </div>
          </div>

          <div className="overflow-x-auto pb-6 mb-8">
            <table className="w-full bg-white shadow-sm rounded-xl border-collapse overflow-hidden text-sm md:text-base min-w-[800px]">
              <thead>
                <tr>
                  <th className="p-4 w-48 bg-gray-50 border-b border-gray-100 text-left text-gray-500 font-medium">
                    คุณสมบัติ
                  </th>
                  {selectedProducts.map(product => (
                    <th key={product.id} className="p-4 border-b border-gray-100 min-w-[250px] relative align-top">
                      <button 
                        onClick={() => toggleProduct(product.id)}
                        className="absolute top-2 right-2 p-1 text-gray-400 hover:text-red-500 rounded-full hover:bg-gray-100 z-10"
                        title="ลบออก"
                      >
                        <X size={16} />
                      </button>
                      <div className="flex flex-col items-center">
                        <div className="w-full h-48 bg-gray-50 rounded-lg mb-4 p-4 flex items-center justify-center">
                            <img 
                                src={product.images?.[0] || product.imageUrl} 
                                alt={product.model} 
                                className="max-w-full max-h-full object-contain mix-blend-multiply" 
                            />
                        </div>
                        <h3 className="text-lg font-bold text-gray-900 mb-1">{product.model}</h3>
                        <span className={`px-2 py-0.5 rounded text-xs font-bold ${
                          product.type === 'Color' ? 'bg-blue-100 text-blue-700' : 'bg-gray-100 text-gray-700'
                        }`}>
                          {product.type === 'Color' ? 'Color' : 'Black & White'}
                        </span>
                      </div>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                <tr>
                  <td className="p-4 font-bold text-gray-700 bg-gray-50">ความเร็วการพิมพ์</td>
                  {selectedProducts.map(product => (
                    <td key={product.id} className="p-4 text-center">
                      <span className="font-bold text-lg text-kyocera-black">{product.speed}</span> แผ่น/นาที
                    </td>
                  ))}
                </tr>
                <tr>
                  <td className="p-4 font-bold text-gray-700 bg-gray-50">ขนาดกระดาษสูงสุด</td>
                  {selectedProducts.map(product => (
                    <td key={product.id} className="p-4 text-center">
                      {product.category}
                    </td>
                  ))}
                </tr>
                <tr>
                  <td className="p-4 font-bold text-gray-700 bg-gray-50">ระดับราคา</td>
                  {selectedProducts.map(product => (
                    <td key={product.id} className="p-4 text-center text-kyocera-red font-medium">
                      {product.priceRange}
                    </td>
                  ))}
                </tr>
                <tr>
                  <td className="p-4 font-bold text-gray-700 bg-gray-50">รายละเอียด</td>
                  {selectedProducts.map(product => (
                    <td key={product.id} className="p-4 text-center text-gray-600 leading-relaxed">
                      {product.description}
                    </td>
                  ))}
                </tr>
                <tr>
                  <td className="p-4 font-bold text-gray-700 bg-gray-50 align-top">ฟีเจอร์เด่น</td>
                  {selectedProducts.map(product => (
                    <td key={product.id} className="p-4 align-top">
                      <ul className="space-y-2 text-left inline-block">
                        {product.features.map((feature, idx) => (
                          <li key={idx} className="flex items-start gap-2 text-sm text-gray-600">
                            <CheckCircle size={14} className="text-green-500 mt-1 flex-shrink-0" />
                            {feature}
                          </li>
                        ))}
                      </ul>
                    </td>
                  ))}
                </tr>
                <tr>
                  <td className="p-4 bg-gray-50 border-t border-gray-100"></td>
                  {selectedProducts.map(product => (
                    <td key={product.id} className="p-4 text-center border-t border-gray-100">
                      <Link 
                        to={`/product/${product.id}`} 
                        className="block w-full py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 font-medium mb-2"
                      >
                        ดูรายละเอียด
                      </Link>
                      <Link 
                        to="/contact" 
                        className="block w-full py-2 bg-kyocera-red rounded-lg text-white hover:bg-red-700 font-medium"
                      >
                        ขอใบเสนอราคา
                      </Link>
                    </td>
                  ))}
                </tr>
              </tbody>
            </table>
          </div>

          {/* AI Analysis Section */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 md:p-8">
            <div className="flex items-center gap-3 mb-6">
                <div className="bg-gradient-to-r from-blue-600 to-purple-600 text-white p-2.5 rounded-lg shadow-md">
                    <Sparkles size={24} />
                </div>
                <div>
                    <h2 className="text-xl font-bold text-gray-900">AI Comparison Assistant</h2>
                    <p className="text-sm text-gray-500">ถามความแตกต่างหรือขอคำแนะนำเกี่ยวกับรุ่นที่เลือก เพื่อการตัดสินใจที่แม่นยำที่สุด</p>
                </div>
            </div>

            {/* Quick Actions */}
            <div className="flex flex-wrap gap-2 mb-6">
                {['สรุปความแตกต่างหลัก', 'รุ่นไหนคุ้มค่าที่สุด?', 'รุ่นไหนเหมาะกับงานเอกสารเยอะ?'].map(q => (
                    <button
                        key={q}
                        onClick={() => handleAiCompare(q)}
                        disabled={isAiLoading}
                        className="px-4 py-2 bg-gray-50 hover:bg-gray-100 text-gray-700 text-sm rounded-full border border-gray-200 transition-colors"
                    >
                        {q}
                    </button>
                ))}
            </div>

            {/* Input Area */}
            <div className="relative mb-6">
                <input
                    type="text"
                    value={aiQuery}
                    onChange={(e) => setAiQuery(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleAiCompare()}
                    placeholder="พิมพ์คำถามของคุณเกี่ยวกับสินค้าเหล่านี้..."
                    className="w-full pl-5 pr-12 py-4 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all text-gray-800 placeholder-gray-400"
                    disabled={isAiLoading}
                />
                <button
                    onClick={() => handleAiCompare()}
                    disabled={isAiLoading || !aiQuery.trim()}
                    className="absolute right-2 top-2 bottom-2 bg-blue-600 text-white p-2.5 rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:hover:bg-blue-600 transition-colors shadow-sm flex items-center justify-center min-w-[44px]"
                >
                    {isAiLoading ? <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : <Send size={20} />}
                </button>
            </div>

            {/* Response Area */}
            {aiResponse && (
                <div className="bg-blue-50/50 border border-blue-100 rounded-xl p-6 animate-in fade-in slide-in-from-bottom-2">
                    <div className="flex gap-3 items-start">
                        <Bot className="text-blue-600 flex-shrink-0 mt-1" size={24} />
                        <div className="prose prose-sm max-w-none text-gray-700 leading-relaxed whitespace-pre-line">
                            {aiResponse}
                        </div>
                    </div>
                </div>
            )}
          </div>

        </div>
      </div>
    </>
  );
};

export default Compare;
