import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, CheckCircle, Star } from 'lucide-react';
import SeoHead from '../components/SeoHead';

const Home: React.FC = () => {
  return (
    <>
      <SeoHead 
        title="หน้าแรก" 
        description="บริการจำหน่ายและเช่าเครื่องถ่ายเอกสาร Kyocera คุณภาพสูง พร้อมทีมงานมืออาชีพและ AI ช่วยเลือก" 
      />
      
      {/* Hero Section */}
      <section className="relative bg-gradient-to-r from-gray-900 to-gray-800 text-white py-20 lg:py-32 overflow-hidden">
        <div className="absolute inset-0 opacity-10 bg-[url('https://picsum.photos/id/45/1920/1080')] bg-cover bg-center"></div>
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-3xl">
            <span className="inline-block px-4 py-1 rounded-full bg-red-900/50 text-red-200 text-xs font-bold tracking-wider mb-6 border border-red-800">
              ตัวแทนจำหน่ายอย่างเป็นทางการ
            </span>
            <h1 className="text-4xl lg:text-6xl font-bold leading-tight mb-6">
              ยกระดับงานเอกสาร<br />
              ด้วยนวัตกรรม <span className="text-kyocera-red">Kyocera</span>
            </h1>
            <p className="text-lg text-gray-300 mb-8 leading-relaxed max-w-2xl">
              เครื่องถ่ายเอกสารที่ออกแบบมาเพื่อความคุ้มค่า ทนทาน และเป็นมิตรต่อสิ่งแวดล้อม 
              พร้อมเทคโนโลยี AI ที่ช่วยให้ธุรกิจของคุณราบรื่นไม่มีสะดุด
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Link to="/catalog" className="px-8 py-4 bg-kyocera-red hover:bg-red-700 text-white rounded-lg font-bold transition flex items-center justify-center gap-2">
                ดูสินค้าทั้งหมด <ArrowRight size={20} />
              </Link>
              <Link to="/contact" className="px-8 py-4 bg-white hover:bg-gray-100 text-gray-900 rounded-lg font-bold transition flex items-center justify-center">
                ขอใบเสนอราคา
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">ทำไมต้องเลือกเรา?</h2>
            <p className="text-gray-600">เราไม่ได้แค่ขายเครื่องถ่ายเอกสาร แต่เราส่งมอบโซลูชั่นที่คุ้มค่าที่สุดสำหรับธุรกิจของคุณ</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="p-8 rounded-2xl bg-gray-50 hover:shadow-xl transition duration-300 border border-gray-100">
              <div className="w-14 h-14 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center mb-6">
                <CheckCircle size={28} />
              </div>
              <h3 className="text-xl font-bold mb-3 text-gray-800">ECOSYS Technology</h3>
              <p className="text-gray-600 leading-relaxed">
                ระบบดรัมแม่แบบที่มีความทนทานสูง ช่วยลดขยะอิเล็กทรอนิกส์และลดต้นทุนต่อแผ่นได้อย่างมหาศาล
              </p>
            </div>
            
            <div className="p-8 rounded-2xl bg-gray-50 hover:shadow-xl transition duration-300 border border-gray-100">
              <div className="w-14 h-14 bg-red-100 text-kyocera-red rounded-full flex items-center justify-center mb-6">
                <Star size={28} />
              </div>
              <h3 className="text-xl font-bold mb-3 text-gray-800">บริการหลังการขาย 24 ชม.</h3>
              <p className="text-gray-600 leading-relaxed">
                ทีมช่างผู้เชี่ยวชาญพร้อมให้บริการ On-site service และระบบ Remote Support แก้ปัญหาทันที
              </p>
            </div>
            
            <div className="p-8 rounded-2xl bg-gray-50 hover:shadow-xl transition duration-300 border border-gray-100">
              <div className="w-14 h-14 bg-purple-100 text-purple-600 rounded-full flex items-center justify-center mb-6">
                <ArrowRight size={28} />
              </div>
              <h3 className="text-xl font-bold mb-3 text-gray-800">AI Consultant</h3>
              <p className="text-gray-600 leading-relaxed">
                นวัตกรรมใหม่บนหน้าเว็บ ปรึกษาผู้ช่วย AI ของเราเพื่อเลือกรุ่นที่เหมาะสมกับการใช้งานของคุณที่สุด
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gray-900 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl lg:text-4xl font-bold mb-6">ยังไม่แน่ใจว่าจะเลือกรุ่นไหน?</h2>
          <p className="text-gray-400 mb-8 max-w-xl mx-auto">
            ลองใช้งานระบบ Chatbot อัจฉริยะที่มุมขวาล่าง หรือติดต่อฝ่ายขายของเราเพื่อรับคำปรึกษาฟรี
          </p>
          <Link to="/contact" className="inline-block px-8 py-3 rounded-full border-2 border-white hover:bg-white hover:text-gray-900 transition font-medium">
            ติดต่อฝ่ายขาย
          </Link>
        </div>
      </section>
    </>
  );
};

export default Home;