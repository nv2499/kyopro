
import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { products } from '../data/products';
import { Filter, ArrowRight, Check, Zap, Layers, FileText, X } from 'lucide-react';
import SeoHead from '../components/SeoHead';
import { useComparison } from '../context/ComparisonContext';

const Catalog: React.FC = () => {
  const [filterType, setFilterType] = useState<'All' | 'Color' | 'B&W'>('All');
  const [filterCategory, setFilterCategory] = useState<'All' | 'A3' | 'A4'>('All');
  const [filterPrice, setFilterPrice] = useState<'All' | 'Economy' | 'Standard' | 'Premium'>('All');
  
  const { isInComparison, toggleProduct } = useComparison();

  // Helper to determine price class from '฿' string
  const getPriceClass = (price: string) => {
    if (price.length <= 2) return 'Economy';
    if (price.length === 3) return 'Standard';
    return 'Premium';
  };

  const filteredProducts = products.filter(p => {
    const matchType = filterType === 'All' || p.type === filterType;
    const matchCategory = filterCategory === 'All' || p.category === filterCategory;
    const matchPrice = filterPrice === 'All' || getPriceClass(p.priceRange) === filterPrice;
    
    return matchType && matchCategory && matchPrice;
  });

  const clearFilters = () => {
    setFilterType('All');
    setFilterCategory('All');
    setFilterPrice('All');
  };

  const hasActiveFilters = filterType !== 'All' || filterCategory !== 'All' || filterPrice !== 'All';

  return (
    <>
      <SeoHead 
        title="สินค้าทั้งหมด" 
        description="รายการเครื่องถ่ายเอกสาร Kyocera ทุกรุ่น ขาว-ดำ และ สี ประสิทธิภาพสูง ราคาคุ้มค่า" 
      />

      <div className="bg-gray-50 min-h-screen py-12">
        <div className="container mx-auto px-4 max-w-7xl">
          
          {/* Header Section */}
          <div className="flex flex-col md:flex-row justify-between items-start md:items-end mb-8 gap-6">
            <div>
              <h1 className="text-4xl font-bold text-gray-900 mb-3 tracking-tight">สินค้าทั้งหมด</h1>
              <p className="text-lg text-gray-500">เลือกชมเครื่องถ่ายเอกสารคุณภาพสูงจาก Kyocera ที่เหมาะกับธุรกิจของคุณ</p>
            </div>
            
            {hasActiveFilters && (
                <button 
                    onClick={clearFilters}
                    className="flex items-center gap-2 text-red-600 hover:text-red-700 font-medium px-4 py-2 bg-red-50 rounded-lg transition-colors"
                >
                    <X size={16} /> ล้างตัวกรอง
                </button>
            )}
          </div>

          {/* Advanced Filter Bar */}
          <div className="bg-white p-6 rounded-2xl border border-gray-200 shadow-sm mb-12 flex flex-col lg:flex-row gap-8">
            
            {/* Type Filter */}
            <div className="flex flex-col gap-3 min-w-[200px]">
                <label className="text-xs font-bold text-gray-400 uppercase tracking-wider flex items-center gap-2">
                    <Layers size={14} /> ระบบสี
                </label>
                <div className="flex gap-2">
                    {['All', 'B&W', 'Color'].map((type) => (
                        <button 
                            key={type}
                            onClick={() => setFilterType(type as any)}
                            className={`flex-1 px-4 py-2 rounded-lg text-sm font-bold transition-all duration-200 border ${
                                filterType === type 
                                ? 'bg-kyocera-black text-white border-kyocera-black shadow-md' 
                                : 'bg-white text-gray-600 border-gray-200 hover:border-gray-300 hover:bg-gray-50'
                            }`}
                        >
                            {type === 'All' ? 'ทั้งหมด' : type === 'B&W' ? 'ขาว-ดำ' : 'สี'}
                        </button>
                    ))}
                </div>
            </div>

            <div className="w-px bg-gray-100 hidden lg:block"></div>

            {/* Category Filter */}
            <div className="flex flex-col gap-3 min-w-[200px]">
                <label className="text-xs font-bold text-gray-400 uppercase tracking-wider flex items-center gap-2">
                    <FileText size={14} /> ขนาดกระดาษ
                </label>
                <div className="flex gap-2">
                    {['All', 'A3', 'A4'].map((cat) => (
                        <button 
                            key={cat}
                            onClick={() => setFilterCategory(cat as any)}
                            className={`flex-1 px-4 py-2 rounded-lg text-sm font-bold transition-all duration-200 border ${
                                filterCategory === cat 
                                ? 'bg-kyocera-black text-white border-kyocera-black shadow-md' 
                                : 'bg-white text-gray-600 border-gray-200 hover:border-gray-300 hover:bg-gray-50'
                            }`}
                        >
                            {cat === 'All' ? 'ทั้งหมด' : cat}
                        </button>
                    ))}
                </div>
            </div>

            <div className="w-px bg-gray-100 hidden lg:block"></div>

            {/* Price Filter */}
            <div className="flex flex-col gap-3 flex-grow">
                <label className="text-xs font-bold text-gray-400 uppercase tracking-wider flex items-center gap-2">
                    <Zap size={14} /> ระดับราคา
                </label>
                <div className="flex gap-2 overflow-x-auto pb-1 md:pb-0">
                    {[
                        { id: 'All', label: 'ทั้งหมด' },
                        { id: 'Economy', label: 'Economy (฿-฿฿)' },
                        { id: 'Standard', label: 'Standard (฿฿฿)' },
                        { id: 'Premium', label: 'Premium (฿฿฿฿+)' }
                    ].map((price) => (
                        <button 
                            key={price.id}
                            onClick={() => setFilterPrice(price.id as any)}
                            className={`whitespace-nowrap px-4 py-2 rounded-lg text-sm font-bold transition-all duration-200 border ${
                                filterPrice === price.id 
                                ? 'bg-kyocera-black text-white border-kyocera-black shadow-md' 
                                : 'bg-white text-gray-600 border-gray-200 hover:border-gray-300 hover:bg-gray-50'
                            }`}
                        >
                            {price.label}
                        </button>
                    ))}
                </div>
            </div>

          </div>

          {/* Product Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-3 gap-8">
            {filteredProducts.map((product) => {
              const isSelected = isInComparison(product.id);
              return (
              <div key={product.id} className="bg-white rounded-2xl border border-gray-100 hover:border-red-100 shadow-sm hover:shadow-xl transition-all duration-300 group flex flex-col h-full relative overflow-hidden hover:-translate-y-1">
                
                {/* Floating Tags */}
                <div className="absolute top-4 left-4 z-20 flex flex-col gap-2">
                   <span className={`px-3 py-1.5 rounded-lg text-xs font-bold shadow-sm backdrop-blur-md ${
                      product.type === 'Color' 
                        ? 'bg-blue-600/90 text-white' 
                        : 'bg-gray-800/90 text-white'
                    }`}>
                      {product.type === 'Color' ? 'พิมพ์สี' : 'ขาว-ดำ'}
                    </span>
                </div>

                {/* Compare Button */}
                <div className="absolute top-4 right-4 z-20">
                     <button
                        onClick={(e) => {
                            e.preventDefault();
                            toggleProduct(product.id);
                        }}
                        className={`group/btn flex items-center justify-center w-10 h-10 rounded-full shadow-md transition-all duration-300 backdrop-blur-sm ${
                            isSelected 
                            ? 'bg-kyocera-red text-white ring-2 ring-red-200 scale-110' 
                            : 'bg-white/90 text-gray-400 hover:text-kyocera-red hover:bg-white'
                        }`}
                        title={isSelected ? "ยกเลิกการเปรียบเทียบ" : "เปรียบเทียบ"}
                    >
                        {isSelected ? <Check size={18} strokeWidth={3} /> : <Layers size={18} />}
                    </button>
                </div>

                {/* Image Section */}
                <Link to={`/product/${product.id}`} className="block relative h-72 overflow-hidden bg-gray-50 group-hover:bg-gray-100/50 transition-colors">
                  <div className="absolute inset-0 flex items-center justify-center p-8">
                      <img 
                        src={product.imageUrl} 
                        alt={product.model} 
                        className="w-full h-full object-contain group-hover:scale-110 transition-transform duration-500 ease-out drop-shadow-md"
                      />
                  </div>
                </Link>
                
                {/* Content Section */}
                <div className="p-6 flex-1 flex flex-col">
                  <div className="mb-4">
                    <div className="flex justify-between items-start mb-2">
                        <span className="text-xs font-bold text-gray-400 uppercase tracking-wider flex items-center gap-1">
                            <FileText size={12} /> {product.category} Series
                        </span>
                        <div className="text-kyocera-red text-xs font-bold px-2 py-0.5 bg-red-50 rounded-md">
                            {product.priceRange}
                        </div>
                    </div>
                    <Link to={`/product/${product.id}`} className="group-hover:text-kyocera-red transition-colors block">
                        <h2 className="text-2xl font-bold text-gray-900 leading-tight mb-2">{product.model}</h2>
                    </Link>
                    <p className="text-sm text-gray-500 line-clamp-2 leading-relaxed h-10">{product.description}</p>
                  </div>
                  
                  {/* Quick Specs Grid */}
                  <div className="grid grid-cols-2 gap-3 mb-6 bg-gray-50 rounded-xl p-3 border border-gray-100">
                    <div className="flex items-center gap-2">
                        <div className="w-8 h-8 rounded-lg bg-white flex items-center justify-center text-kyocera-red shadow-sm border border-gray-100">
                            <Zap size={16} />
                        </div>
                        <div className="flex flex-col">
                            <span className="text-[10px] text-gray-400 font-bold uppercase">Speed</span>
                            <span className="text-sm font-bold text-gray-700">{product.speed} ppm</span>
                        </div>
                    </div>
                     <div className="flex items-center gap-2">
                        <div className="w-8 h-8 rounded-lg bg-white flex items-center justify-center text-blue-600 shadow-sm border border-gray-100">
                            <Layers size={16} />
                        </div>
                        <div className="flex flex-col">
                            <span className="text-[10px] text-gray-400 font-bold uppercase">Type</span>
                            <span className="text-sm font-bold text-gray-700">{product.type}</span>
                        </div>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="mt-auto pt-4 border-t border-gray-100">
                    <Link 
                        to={`/product/${product.id}`} 
                        className="flex items-center justify-center w-full py-3 rounded-xl font-bold text-sm bg-gray-900 text-white group-hover:bg-kyocera-red transition-colors duration-300 gap-2 shadow-sm"
                    >
                        ดูรายละเอียด <ArrowRight size={16} />
                    </Link>
                  </div>
                </div>
              </div>
            )})}
          </div>

          {filteredProducts.length === 0 && (
            <div className="flex flex-col items-center justify-center py-24 bg-white rounded-3xl border-2 border-dashed border-gray-200">
              <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center text-gray-400 mb-4">
                  <Filter size={32} />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-1">ไม่พบสินค้าที่ตรงตามเงื่อนไข</h3>
              <p className="text-gray-500 mb-6">ลองปรับเปลี่ยนตัวเลือกการกรองสินค้าของคุณ</p>
              <button 
                onClick={clearFilters}
                className="px-6 py-2 bg-gray-900 text-white rounded-lg font-bold hover:bg-gray-800 transition"
              >
                ล้างตัวกรองทั้งหมด
              </button>
            </div>
          )}
        </div>
      </div>
    </>
  );
};

export default Catalog;
