import React, { createContext, useContext, useState } from 'react';

interface ComparisonContextType {
  selectedIds: string[];
  toggleProduct: (id: string) => void;
  clearComparison: () => void;
  isInComparison: (id: string) => boolean;
}

const ComparisonContext = createContext<ComparisonContextType | undefined>(undefined);

export const ComparisonProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [selectedIds, setSelectedIds] = useState<string[]>([]);

  const toggleProduct = (id: string) => {
    setSelectedIds(prev => {
      if (prev.includes(id)) {
        return prev.filter(itemId => itemId !== id);
      } else {
        if (prev.length >= 4) {
          alert('คุณสามารถเปรียบเทียบสินค้าได้สูงสุด 4 รายการ');
          return prev;
        }
        return [...prev, id];
      }
    });
  };

  const clearComparison = () => setSelectedIds([]);
  const isInComparison = (id: string) => selectedIds.includes(id);

  return (
    <ComparisonContext.Provider value={{ selectedIds, toggleProduct, clearComparison, isInComparison }}>
      {children}
    </ComparisonContext.Provider>
  );
};

export const useComparison = () => {
  const context = useContext(ComparisonContext);
  if (!context) throw new Error('useComparison must be used within a ComparisonProvider');
  return context;
};