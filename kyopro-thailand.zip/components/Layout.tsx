import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, Printer, Phone, Home, BookOpen, Layers } from 'lucide-react';
import AiAssistant from './AiAssistant';
import CompareBar from './CompareBar';

const Layout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const location = useLocation();

  const navLinks = [
    { name: 'หน้าแรก', path: '/', icon: <Home className="w-4 h-4"/> },
    { name: 'สินค้าทั้งหมด', path: '/catalog', icon: <Printer className="w-4 h-4"/> },
    { name: 'เปรียบเทียบ', path: '/compare', icon: <Layers className="w-4 h-4"/> },
    { name: 'ติดต่อเรา', path: '/contact', icon: <Phone className="w-4 h-4"/> },
  ];

  const isActive = (path: string) => location.pathname === path;

  return (
    <div className="min-h-screen flex flex-col bg-gray-50 text-gray-800 font-sans">
      {/* Navigation */}
      <nav className="bg-white shadow-md sticky top-0 z-40">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center h-20">
            {/* Logo */}
            <Link to="/" className="flex items-center gap-2">
              <div className="bg-kyocera-red text-white p-2 rounded-lg">
                <Printer size={28} />
              </div>
              <div className="flex flex-col">
                <span className="text-xl font-bold tracking-tight text-kyocera-black">KYOPRO</span>
                <span className="text-xs text-gray-500 uppercase tracking-widest">Thailand</span>
              </div>
            </Link>

            {/* Desktop Menu */}
            <div className="hidden md:flex space-x-8">
              {navLinks.map((link) => (
                <Link
                  key={link.path}
                  to={link.path}
                  className={`flex items-center gap-2 px-3 py-2 rounded-md transition-colors text-sm font-medium ${
                    isActive(link.path)
                      ? 'text-kyocera-red bg-red-50'
                      : 'text-gray-600 hover:text-kyocera-red hover:bg-gray-50'
                  }`}
                >
                  {link.icon}
                  {link.name}
                </Link>
              ))}
            </div>

            {/* Mobile Menu Button */}
            <div className="md:hidden">
              <button
                onClick={() => setIsMenuOpen(!isMenuOpen)}
                className="text-gray-600 hover:text-kyocera-red focus:outline-none"
              >
                {isMenuOpen ? <X size={28} /> : <Menu size={28} />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Dropdown */}
        {isMenuOpen && (
          <div className="md:hidden bg-white border-t border-gray-100 pb-4">
            <div className="container mx-auto px-4 flex flex-col space-y-2 pt-4">
              {navLinks.map((link) => (
                <Link
                  key={link.path}
                  to={link.path}
                  onClick={() => setIsMenuOpen(false)}
                  className={`flex items-center gap-3 px-4 py-3 rounded-lg ${
                    isActive(link.path)
                      ? 'bg-red-50 text-kyocera-red'
                      : 'text-gray-600 hover:bg-gray-50'
                  }`}
                >
                  {link.icon}
                  {link.name}
                </Link>
              ))}
            </div>
          </div>
        )}
      </nav>

      {/* Main Content */}
      <main className="flex-grow">
        {children}
      </main>

      {/* Footer */}
      <footer className="bg-kyocera-black text-white pt-12 pb-8 mb-16 md:mb-0">
        <div className="container mx-auto px-4 grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <Printer className="text-kyocera-red" size={24} />
              <span className="text-lg font-bold">KYOPRO Thailand</span>
            </div>
            <p className="text-gray-400 text-sm leading-relaxed">
              ผู้เชี่ยวชาญด้านโซลูชั่นงานเอกสาร ตัวแทนจำหน่าย Kyocera อย่างเป็นทางการ 
              พร้อมบริการหลังการขายที่รวดเร็ว ฉับไว ครอบคลุมทั่วประเทศ
            </p>
          </div>
          <div>
            <h4 className="text-lg font-bold mb-4 border-l-4 border-kyocera-red pl-3">เมนูลัด</h4>
            <ul className="space-y-2 text-gray-400 text-sm">
              <li><Link to="/" className="hover:text-white transition">หน้าแรก</Link></li>
              <li><Link to="/catalog" className="hover:text-white transition">สินค้าทั้งหมด</Link></li>
              <li><Link to="/contact" className="hover:text-white transition">ติดต่อเรา</Link></li>
              <li><a href="#" className="hover:text-white transition">แจ้งซ่อม / แจ้งปัญหา</a></li>
            </ul>
          </div>
          <div>
            <h4 className="text-lg font-bold mb-4 border-l-4 border-kyocera-red pl-3">ติดต่อเรา</h4>
            <ul className="space-y-2 text-gray-400 text-sm">
              <li>123 อาคารสาทรทาวเวอร์ ชั้น 15 ถนนสาทรใต้</li>
              <li>ยานนาวา สาทร กรุงเทพฯ 10120</li>
              <li className="flex items-center gap-2 mt-4 text-white">
                <Phone size={16} /> 02-123-4567
              </li>
              <li>Email: sales@kyopro-thailand.com</li>
            </ul>
          </div>
        </div>
        <div className="border-t border-gray-800 pt-8 text-center text-xs text-gray-500">
          © {new Date().getFullYear()} KyoPro Thailand. All rights reserved. Not an official Kyocera Corporation site. Demo purposes only.
        </div>
      </footer>

      {/* Comparison Floating Bar */}
      <CompareBar />

      {/* AI Widget */}
      <AiAssistant />
    </div>
  );
};

export default Layout;