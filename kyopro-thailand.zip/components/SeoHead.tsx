import React from 'react';

interface SeoHeadProps {
  title: string;
  description: string;
  keywords?: string;
  image?: string;
  url?: string;
}

const SeoHead: React.FC<SeoHeadProps> = ({ 
  title, 
  description, 
  keywords = "เครื่องถ่ายเอกสาร Kyocera, เช่าเครื่องถ่ายเอกสาร, ซ่อมเครื่องถ่ายเอกสาร, Kyocera Thailand, TASKalfa, ECOSYS",
  image = "https://picsum.photos/id/1/1200/630",
  url = "https://www.kyopro-thailand.com"
}) => {
  const siteTitle = `${title} | KyoPro Thailand`;

  return (
    <>
      <title>{siteTitle}</title>
      <meta name="description" content={description} />
      <meta name="keywords" content={keywords} />
      
      {/* Open Graph / Facebook */}
      <meta property="og:type" content="website" />
      <meta property="og:url" content={url} />
      <meta property="og:title" content={siteTitle} />
      <meta property="og:description" content={description} />
      <meta property="og:image" content={image} />

      {/* Twitter */}
      <meta name="twitter:card" content="summary_large_image" />
      <meta name="twitter:url" content={url} />
      <meta name="twitter:title" content={siteTitle} />
      <meta name="twitter:description" content={description} />
      <meta name="twitter:image" content={image} />
      
      <link rel="canonical" href={url} />
    </>
  );
};

export default SeoHead;