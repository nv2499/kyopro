import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { products } from "../data/products";

// Initialize the API client.
// Note: In a real production app, ensure requests are proxied via backend to hide API KEY,
// or use strict constraints on the API key if client-side only.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const SYSTEM_INSTRUCTION = `
คุณคือ "KyoPro Assistant" ผู้เชี่ยวชาญด้านการขายเครื่องถ่ายเอกสาร Kyocera ในประเทศไทย
หน้าที่ของคุณคือช่วยเหลือลูกค้าในการเลือกรุ่นเครื่องถ่ายเอกสารที่เหมาะสมกับความต้องการ

ข้อมูลสินค้าที่มีจำหน่าย (ใช้ข้อมูลนี้ในการแนะนำเท่านั้น):
${JSON.stringify(products.map(p => `${p.model} (${p.type}, ${p.category}, ${p.speed}ppm): ${p.description}`))}

แนวทางการตอบ:
1. สุภาพ เป็นมืออาชีพ น่าเชื่อถือ (ใช้ภาษาไทย)
2. ถามคำถามกลับเพื่อประเมินความต้องการลูกค้า เช่น ปริมาณการพิมพ์ต่อเดือน, ต้องการสีหรือขาวดำ, งบประมาณ
3. แนะนำรุ่นที่เหมาะสมที่สุดพร้อมเหตุผลสั้นๆ
4. ถ้าลูกค้าถามเรื่องราคา ให้แนะนำให้ติดต่อฝ่ายขายผ่านหน้า "ติดต่อเรา" เพื่อขอใบเสนอราคาพิเศษ
5. ตอบสั้น กระชับ ไม่เยิ่นเย้อ

ห้ามตอบเรื่องอื่นที่ไม่เกี่ยวกับเครื่องถ่ายเอกสาร หรือ Kyocera
`;

export const sendMessageToGemini = async (history: {role: string, parts: {text: string}[]}[], userMessage: string): Promise<string> => {
  try {
    const chat = ai.chats.create({
      model: 'gemini-2.5-flash',
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        temperature: 0.7,
      },
      history: history // Pass existing history
    });

    const response: GenerateContentResponse = await chat.sendMessage({ message: userMessage });
    return response.text || "ขออภัย ระบบขัดข้องชั่วคราว กรุณาลองใหม่อีกครั้ง";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "ขออภัย เกิดข้อผิดพลาดในการเชื่อมต่อกับ AI Assistant";
  }
};