
import { Product } from '../types';

export const products: Product[] = [
  {
    id: 'taskalfa-2554ci',
    model: 'TASKalfa 2554ci',
    type: 'Color',
    speed: 25,
    category: 'A3',
    priceRange: '฿฿฿',
    description: 'เครื่องถ่ายเอกสารมัลติฟังก์ชั่นสี A3 ประสิทธิภาพสูง รองรับงานพิมพ์คุณภาพคมชัด พร้อมหน้าจอสัมผัสขนาดใหญ่ 10.1 นิ้ว',
    features: ['ความเร็ว 25 แผ่น/นาที', 'ความละเอียด 1200 x 1200 dpi', 'รองรับ Mobile Print', 'AI Super Resolution'],
    imageUrl: 'https://picsum.photos/id/1/600/600',
    images: [
      'https://picsum.photos/id/1/800/800', // Front
      'https://picsum.photos/id/6/800/800', // Side
      'https://picsum.photos/id/180/800/800', // Panel
      'https://picsum.photos/id/20/800/800'  // Paper Tray
    ]
  },
  {
    id: 'taskalfa-3554ci',
    model: 'TASKalfa 3554ci',
    type: 'Color',
    speed: 35,
    category: 'A3',
    priceRange: '฿฿฿฿',
    description: 'ยกระดับการทำงานด้วยความเร็ว 35 แผ่นต่อนาที เหมาะสำหรับสำนักงานขนาดกลางที่ต้องการความรวดเร็วและคุณภาพสีที่แม่นยำ',
    features: ['ความเร็ว 35 แผ่น/นาที', 'สแกนเอกสารได้รวดเร็ว', 'ระบบความปลอดภัย Data Security', 'หน้าจอ UI ใช้งานง่าย'],
    imageUrl: 'https://picsum.photos/id/2/600/600',
    images: [
      'https://picsum.photos/id/2/800/800',
      'https://picsum.photos/id/119/800/800',
      'https://picsum.photos/id/160/800/800'
    ]
  },
  {
    id: 'ecosys-m3645idn',
    model: 'ECOSYS M3645idn',
    type: 'B&W',
    speed: 45,
    category: 'A4',
    priceRange: '฿฿',
    description: 'เครื่องมัลติฟังก์ชั่นขาว-ดำ A4 ทนทาน ประหยัดหมึก ด้วยเทคโนโลยี ECOSYS ที่เป็นเอกลักษณ์ของ Kyocera',
    features: ['ความเร็ว 45 แผ่น/นาที', 'ดรัมแม่แบบอายุการใช้งานยาวนาน', 'ต้นทุนต่อแผ่นต่ำ', 'รองรับ Network Fax'],
    imageUrl: 'https://picsum.photos/id/3/600/600',
    images: [
      'https://picsum.photos/id/3/800/800',
      'https://picsum.photos/id/175/800/800'
    ]
  },
  {
    id: 'ecosys-p3145dn',
    model: 'ECOSYS P3145dn',
    type: 'B&W',
    speed: 45,
    category: 'A4',
    priceRange: '฿',
    description: 'เครื่องพิมพ์เลเซอร์ขาว-ดำ รองรับงานพิมพ์ปริมาณมาก แข็งแรงทนทาน เหมาะสำหรับธุรกิจ SME',
    features: ['ความเร็ว 45 แผ่น/นาที', 'ถาดกระดาษจุได้เยอะ', 'เชื่อมต่อ USB/LAN', 'ประหยัดพลังงาน'],
    imageUrl: 'https://picsum.photos/id/4/600/600',
    images: [
      'https://picsum.photos/id/4/800/800',
      'https://picsum.photos/id/250/800/800'
    ]
  },
  {
    id: 'taskalfa-7004i',
    model: 'TASKalfa 7004i',
    type: 'B&W',
    speed: 70,
    category: 'A3',
    priceRange: '฿฿฿฿฿',
    description: 'เครื่องถ่ายเอกสารขาว-ดำ ความเร็วสูง 70 แผ่นต่อนาที สำหรับองค์กรขนาดใหญ่ งานหนักแค่ไหนก็เอาอยู่',
    features: ['ความเร็ว 70 แผ่น/นาที', 'Finisher เย็บเล่มอัตโนมัติ', 'ความจุถาดกระดาษสูงสุด 7,000 แผ่น', 'ระบบ OCR ในตัว'],
    imageUrl: 'https://picsum.photos/id/5/600/600',
    images: [
      'https://picsum.photos/id/5/800/800',
      'https://picsum.photos/id/201/800/800',
      'https://picsum.photos/id/366/800/800'
    ]
  },
  {
    id: 'ecosys-m8124cidn',
    model: 'ECOSYS M8124cidn',
    type: 'Color',
    speed: 24,
    category: 'A3',
    priceRange: '฿฿฿',
    description: 'เครื่องมัลติฟังก์ชั่นสี A3 ดีไซน์กะทัดรัด ครบจบในเครื่องเดียว เหมาะสำหรับสำนักงานยุคใหม่ที่ต้องการความคล่องตัว',
    features: ['ความเร็ว 24 แผ่น/นาที', 'หน้าจอสัมผัส 4.3 นิ้ว', 'รองรับ HyPAS', 'พิมพ์ผ่านมือถือได้'],
    imageUrl: 'https://picsum.photos/id/7/600/600',
    images: [
      'https://picsum.photos/id/7/800/800',
      'https://picsum.photos/id/111/800/800',
      'https://picsum.photos/id/212/800/800'
    ]
  }
];
